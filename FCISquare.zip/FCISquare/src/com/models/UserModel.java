package com.models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import com.mysql.jdbc.Statement;

public class UserModel {

	
	private String name;
	private String email;
	private String pass;
	private Integer id;
	private Double lat;
	private Double lon;
	
	public String getPass(){
		return this.pass;
	}
	
	public void setPass(String pass){
		this.pass = pass;
	}
	
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Double getLat() {
		return this.lat;
	}

	public void setLat(Double lat) {
		this.lat = lat;
	}

	public Double getLon() {
		return this.lon;
	}

	public void setLon(Double lon) {
		this.lon = lon;
	}
	
	public static UserModel addNewUser(String name, String email, String pass) {
		
		try {
			Connection conn = DBConnection.getActiveConnection();
			
			String sql = "Insert into users (`name`,`email`,`password`) VALUES  (?,?,?)";

			PreparedStatement stmt;
			stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			stmt.setString(1, name);
			stmt.setString(2, email);
			stmt.setString(3, pass);
			stmt.executeUpdate();
			ResultSet rs = stmt.getGeneratedKeys();
			if (rs.next()) 
			{
				UserModel user = new UserModel();
				user.id = rs.getInt(1);
				user.email = email;
				user.pass = pass;
				user.name = name;
				user.lat = 0.0;
				user.lon = 0.0;
				return user;
			}
			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}

	public static UserModel login(String email, String pass) {
		try {
			Connection conn = DBConnection.getActiveConnection();
			String sql = "SELECT * FROM users WHERE email=? AND password=? ";
			PreparedStatement stmt;
			stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			stmt.setString(1, email);
			stmt.setString(2, pass);
			ResultSet rs = stmt.executeQuery();

			if (rs.next()) 
			{
				UserModel user = new UserModel();
				user.setId(rs.getInt("userID"));
				user.setEmail(rs.getString("email"));
				user.setPass(rs.getString("password"));
				user.setName(rs.getString("name"));
				user.setLat(rs.getDouble("lat"));
				user.setLon(rs.getDouble("longt"));
				rs.close();
			    conn.close();
			    return user;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public static boolean updateUserPosition(Integer id, Double lat, Double lon) {
		try{
			Connection conn = DBConnection.getActiveConnection();
			String sql = "Update users set lat = ? , longt = ? where userID = ?";
			PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setDouble(1, lat);
			stmt.setDouble(2, lon);
			stmt.setInt(3, id);
			stmt.executeUpdate();
			return true;
		}catch(SQLException e){
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean getUser(String email) throws SQLException
    {
        boolean found = false;
        
        Connection conn = DBConnection.getActiveConnection();
        PreparedStatement stmt;
        
        String sql = "SELECT  userID FROM users WHERE email = ?";
        
		stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		stmt.setString(1, email);

        ResultSet rs = stmt.executeQuery();
        if (rs.isBeforeFirst() )
        {    
        	 found=true;
        } 
       rs.close();
       conn.close();
       return found;
    }
	
	public static int getUserId(String email) throws SQLException
    {
        int UserId = 0 ;
        
        Connection conn = DBConnection.getActiveConnection();
        PreparedStatement stmt;
        
        String sql = "SELECT  userID FROM users WHERE email = ?";
		stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		stmt.setString(1, email);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) 
        {
            UserId = rs.getInt("userID");
        }
       rs.close();
       conn.close();
       return UserId;
    }
	
	public static String getUserName(int ID) throws SQLException
    {
        String UserName="";
        
        Connection conn = DBConnection.getActiveConnection();
        PreparedStatement stmt;
        
        String sql = "SELECT  name FROM users WHERE userID = ?";
		stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		stmt.setInt(1, ID);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) 
        {
            UserName = rs.getString("name");
        }
       rs.close();
       conn.close();
       return UserName;
    }
	
	public static boolean follow(Integer id,String email) throws ParseException 
	{
		try{
			Connection conn = DBConnection.getActiveConnection();
			int idToFollow=getUserId(email);
			System.out.println("id"+idToFollow);
			
			String sql = "INSERT INTO Followers VALUES ( ? ,?)";
			PreparedStatement stmt,stmt1;
			
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, id);
			stmt.setInt(2, idToFollow);
			stmt.executeUpdate();
			  
			Date date = new Date();
	        SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
	        SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
			String timeAsString = timeFormatter.format(date);
			String DateAsString = dateFormatter.format(date);
	        Date d=dateFormatter.parse(DateAsString);
	        java.sql.Date SQLdate = new java.sql.Date(d.getTime());
	        d=timeFormatter.parse(timeAsString);
		    java.sql.Time SQLtime= new java.sql.Time(d.getTime());
            
			sql="INSERT INTO `FollowersNotification` (`userID`,`Date`,`Seen`,`Time`,`Text`,`FollowerID`) VALUES (?,?,?,?,?,?) ";
			stmt1=conn.prepareStatement(sql);
			stmt1.setInt(1, idToFollow);
			stmt1.setDate(2,SQLdate);
			stmt1.setBoolean(3, false);
			stmt1.setTime(4, SQLtime);
			stmt1.setString(5,getUserName(id) +" Followed you.");
			stmt1.setInt(6, id);
			stmt1.executeUpdate();
			
			return true;
		}catch(SQLException e){
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean unfollowUser(int id, String email) throws SQLException
	{
		int friendId = getUserId(email);
		try {
			Connection conn = DBConnection.getActiveConnection();
			String sql = "DELETE FROM Followers WHERE FollowerID = ? AND FollowedUserID = ?";
			PreparedStatement stmt = null;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1,id);
			stmt.setInt(2, friendId);
			stmt.executeUpdate();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public static String getLastLocation(Integer id) {

		String lastLocation = null ;
		try {

			Connection conn = DBConnection.getActiveConnection();
			String sql = "Select * from users where userID = ?";
			PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			UserModel user = new UserModel();
			if (rs.next()) 
			{
				  user.lat = rs.getDouble("lat");
		          user.lon = rs.getDouble("longt");
	        }

			lastLocation =getLastLocationName(user.lat , user.lon) + ", latitude : "+Double.toString(user.lat)+", longitude : "+Double.toString(user.lon) ;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lastLocation ;
	}
    
	public static String getLastLocationName(Double lat , Double lon){
        String lastLocationName = null ;
		try {

			Connection conn = DBConnection.getActiveConnection();
			String sql = "Select * from places where lat = ? AND longt = ?";
			PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setDouble(1, lat);
			stmt.setDouble(2, lon);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) 
			{
				lastLocationName = rs.getString("name") ;
	        }
            
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lastLocationName ;
    }

	public static List <UserModel> getAllFollowers (int followedUserID)
    {
    	ArrayList <String> str = new ArrayList <>();
    	List <UserModel> followers = new ArrayList <>();
    	try
    	{
	    	Connection conn = DBConnection.getActiveConnection();
	    	String sql = "Select name,email from users,Followers where Followers.FollowerID = users.userID and FollowedUserID = ?";
	    	PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, followedUserID);
			ResultSet rs = stmt.executeQuery();
			while (rs.next())
			{	
				str.add(rs.getString("name"));
				str.add(rs.getString("email"));
			}
			int n= str.size();

			for(int i=0,j=0;i<n && j<n;i++,j+=2)
			{
				followers.add(new UserModel());
				followers.get(i).setName(str.get(j));
				followers.get(i).setEmail(str.get(j+1)) ;

			}	
    	}
    	catch(SQLException e)
    	{
			e.printStackTrace();
    	}
    	return followers;
    }
	

	
	

	
	
	
	public String toString() 
	{ 	
		String s = null;
		if (name != null)
		{
			s="name:" +this.name;
		}

		
	    return s;
	} 
	

}
