package com.models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ActionModel 
{
	private int actionID;
	private int userID;
	private String actionType;
	
	
	public ActionModel(int actionID, int userID, String actionType) {
		super();
		this.actionID = actionID;
		this.userID = userID;
		this.actionType = actionType;
	}

	public int getActionID() {
		return actionID;
	}

	public void setActionID(int actionID) {
		this.actionID = actionID;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	
	
	public static Boolean undoAction(ActionModel action)
	{
		
		try{
			Connection conn = DBConnection.getActiveConnection();		
			String sql ;
			PreparedStatement stmt;
			
			if(action.getActionType().equals("like"))
			{
				sql="DELETE FROM Likes WHERE LikeID=? AND userID=?";
				stmt = conn.prepareStatement(sql);
				stmt.setInt(1, action.getActionID());
				stmt.setInt(2, action.getUserID());
				stmt.executeUpdate();
				stmt.clearBatch();
				sql="DELETE FROM Actions WHERE actionID=? AND userID=? AND type=?";
				stmt = conn.prepareStatement(sql);
				stmt.setInt(1, action.getActionID());
				stmt.setInt(2, action.getUserID());
				stmt.setString(3, action.getActionType());
				stmt.executeUpdate();
				stmt.clearBatch();
				return true;
			}
			else if(action.getActionType().equals("comment"))
			{
				sql="DELETE FROM Comments WHERE CommentID=? AND userID=?";
				stmt = conn.prepareStatement(sql);
				stmt.setInt(1, action.getActionID());
				stmt.setInt(2, action.getUserID());
				stmt.executeUpdate();
				stmt.clearBatch();
				sql="DELETE FROM Actions WHERE actionID=? AND userID=? AND type=?";
				stmt = conn.prepareStatement(sql);
				stmt.setInt(1, action.getActionID());
				stmt.setInt(2, action.getUserID());
				stmt.setString(3, action.getActionType());
				stmt.executeUpdate();
				return true;
			}
			
			
			return false;
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		return false;
	}
	
	public static List<ActionModel> HistoryOfActions(int userID)
	{
		List<ActionModel> actions=new ArrayList<>();
		
		try {
			Connection conn = DBConnection.getActiveConnection();		
			String sql ;
			PreparedStatement stmt;
			sql="SELECT * FROM Actions WHERE userID=?";
			stmt=conn.prepareStatement(sql);
			stmt.setInt(1,userID);
			ResultSet rs=stmt.executeQuery();
			while(rs.next())
			{
				actions.add(new ActionModel(rs.getInt("actionID"),userID,rs.getString("type")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return actions;
		
	}
}
