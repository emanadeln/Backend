package com.models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class Notification 
{
	private String Date;
	private boolean Seen;
	private String Text;
	private String Time;
	private String Type;
	private int CheckinID;
	private int FollowerID;

	
	public int getFollowerID() {
		return FollowerID;
	}
	public void setFollowerID(int followerID) {
		FollowerID = followerID;
	}
	
	public int getCheckinID() {
		return CheckinID;
	}
	public void setCheckinID(int checkinID) {
		CheckinID = checkinID;
	}
	
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	
	
	public boolean isSeen() {
		return Seen;
	}
	public void setSeen(boolean seen) {
		Seen = seen;
	}
	
	public String getText() {
		return Text;
	}
	public void setText(String text) {
		Text = text;
	}
	
	
	public String getTime() {
		return Time;
	}
	public void setTime(String time) {
		Time = time;
	}
	
	
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	
	public static List <Notification> getAllNotifications (int UserID)
	{
    	List <Notification> allNotifications = new ArrayList <>();
    	try
    	{
	    	Connection conn = DBConnection.getActiveConnection();
	    	String sql = "Select Type,Text,Time,Date,CheckInID,Seen from Notification where userID = ?";
	    	PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1,UserID);
			ResultSet rs = stmt.executeQuery();
			int i=0;
			while (rs.next())
			{	
				allNotifications.add(new Notification());
				allNotifications.get(i).setType(rs.getString("Type"));
				allNotifications.get(i).setText(rs.getString("Text"));
				DateFormat df = new SimpleDateFormat("HH:mm:ss");
				String text = df.format(rs.getTime("Time"));
				allNotifications.get(i).setTime(text);
				df=new SimpleDateFormat("dd/MM/yyyy");
				text=df.format(rs.getDate("Date"));
				allNotifications.get(i).setDate(text);
				allNotifications.get(i).setCheckinID(rs.getInt("CheckInID"));
				allNotifications.get(i).setSeen(rs.getBoolean("Seen"));
				i++;
			}
			
    	}
    	catch(SQLException e)
    	{
			e.printStackTrace();
    	}
    	return allNotifications;
	}

	public static List <Notification> getAllFollowNotifications (int UserID)
	{
    	List <Notification> allNotifications = new ArrayList <>();
    	try
    	{
	    	Connection conn = DBConnection.getActiveConnection();
	    	String sql = "Select FollowerID,Text,Time,Date,Seen from FollowersNotification where userID = ?";
	    	PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1,UserID);
			ResultSet rs = stmt.executeQuery();
			int i=0;
			while (rs.next())
			{	
				allNotifications.add(new Notification());
				allNotifications.get(i).setFollowerID(rs.getInt("FollowerID"));
				allNotifications.get(i).setText(rs.getString("Text"));
				DateFormat df = new SimpleDateFormat("HH:mm:ss");
				String text = df.format(rs.getTime("Time"));
				allNotifications.get(i).setTime(text);
				df=new SimpleDateFormat("dd/MM/yyyy");
				text=df.format(rs.getDate("Date"));
				allNotifications.get(i).setDate(text);
				allNotifications.get(i).setSeen(rs.getBoolean("Seen"));
				i++;
			}
			
    	}
    	catch(SQLException e)
    	{
			e.printStackTrace();
    	}
    	return allNotifications;
	}
	
	public static int RespondToNotif(int NotificationID)
	{
		int checkinID=0;
		try{
			Connection conn = DBConnection.getActiveConnection();		
			String sql = "SELECT CheckInID FROM Notification WHERE NotifID=?";
			PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, NotificationID);
			ResultSet rs = stmt.executeQuery();
			while (rs.next())
			{	
				checkinID=rs.getInt("CheckInID");
			}
			return checkinID;
		}catch(SQLException e){
			e.printStackTrace();
		}
		return checkinID;
	}

	
	
	
	
}
