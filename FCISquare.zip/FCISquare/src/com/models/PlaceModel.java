package com.models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

public class PlaceModel implements Comparable<PlaceModel>
{
	public int numOfCheckIns;
	public String name;
	public double rate;
	

	public PlaceModel(int numOfCheckIns, String name, double rate) {
		super();
		this.numOfCheckIns = numOfCheckIns;
		this.name = name;
		this.rate = rate;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNumOfCheckIns() {
		return numOfCheckIns;
	}
	public void setNumOfCheckIns(int numOfCheckIns) {
		this.numOfCheckIns = numOfCheckIns;
	}
	
	public PlaceModel(String name,int numOfCheckIns) {
		super();
		this.numOfCheckIns = numOfCheckIns;
		
		this.name = name;
	}
	
	
	public static Boolean addNewPlaces(String name, String description, double lat, double longt) 
	{
		try{
			Connection conn = DBConnection.getActiveConnection();		
			String sql = "INSERT INTO places (name , description , lat , longt) VALUES (?,?,?,?)";
			PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, name);
			stmt.setString(2, description);
			stmt.setDouble(3, lat);
			stmt.setDouble(4, longt);
			stmt.executeUpdate();
			return true;
		}catch(SQLException e){
			e.printStackTrace();
		}
		return false;
	}
	

	public static Boolean savePlace(int placeID, int userID) 
	{
		try{
			Connection conn = DBConnection.getActiveConnection();		
			String sql = "INSERT INTO SavedPlaces (placeID , userID) VALUES (?,?)";
			PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, placeID);
			stmt.setInt(2, userID);
			stmt.executeUpdate();
			return true;
		}catch(SQLException e){
			e.printStackTrace();
		}
		return false;
	}


	
	public static boolean ratePlace(double rate, int placeID)
	{
		try
    	{
	    	Connection conn = DBConnection.getActiveConnection();
	    	String sql = "Select places.rate from places where places.id = ?";
	    	PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, placeID);
			ResultSet rs = stmt.executeQuery();
			double oldRate=(double) 0;
			while(rs.next())
			{
				oldRate = rs.getDouble("rate");
			}
			
			sql = "Update places set places.rate = ? where places.id = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setDouble(1, ((oldRate+rate)/2));
			stmt.setInt(2, placeID);
			stmt.executeUpdate();
			return true;
    	}
    	catch(SQLException e)
    	{
			e.printStackTrace();
    	}
		return false;
	}
	public static ArrayList<PlaceModel> SortPlaces(int userID)
	{
		//according to number of check-ins to each place
		ArrayList <PlaceModel> Places = new ArrayList <>();
		try
    	{
	    	Connection conn = DBConnection.getActiveConnection();
	    	String sql = "Select places.NoOfCheckins, places.name , places.rate from places, SavedPlaces where SavedPlaces.userID = ? AND SavedPlaces.placeID = places.id";
	    	
	    	PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, userID);
			ResultSet rs = stmt.executeQuery();
			while (rs.next())
			{	
				Places.add(new PlaceModel( rs.getInt("NoOfCheckins"),rs.getString("name"),rs.getDouble("rate")));
				
			}
    	}
    	catch(SQLException e)
    	{
			e.printStackTrace();
    	}
		Collections.sort(Places);
		return Places;
	}
	
	public static ArrayList<PlaceModel> SortRatedPlaces(int userID)
	{
		//according to each place's rate
		ArrayList <PlaceModel> Places = new ArrayList <>();
		
		try
    	{
	    	Connection conn = DBConnection.getActiveConnection();
	    	String sql = "Select places.NoOfCheckins , places.name ,places.rate from places, SavedPlaces where SavedPlaces.userID = ? AND SavedPlaces.placeID = places.id ORDER BY places.rate";
	    	
	    	PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, userID);
			ResultSet rs = stmt.executeQuery();
			while (rs.next())
			{	
				Places.add(new PlaceModel(rs.getInt("NoOfCheckins") ,rs.getString("name"), rs.getDouble("rate")));
				
			}
    	}
    	catch(SQLException e)
    	{
			e.printStackTrace();
    	}
		
		return Places;
	}
	
	public static ArrayList <PlaceModel> ShowSavedPlaces(int userID)
	{
		ArrayList <PlaceModel> savedPlaces = new ArrayList <>();
		try
    	
    	{
	    	Connection conn = DBConnection.getActiveConnection();
	    	String sql = "Select places.name,NoOfCheckins,rate from places, SavedPlaces where places.id = SavedPlaces.placeID and SavedPlaces.userID in"
	    			+ "(SELECT FollowedUserID FROM Followers WHERE FollowerID =?)";
	    	PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, userID);
			ResultSet rs = stmt.executeQuery();
			while (rs.next())
			{	
				savedPlaces.add(new PlaceModel(rs.getInt("NoOfCheckins") ,rs.getString("name"), rs.getDouble("rate")));
				
			}
    	}
    	catch(SQLException e)
    	{
			e.printStackTrace();
    	}
		return savedPlaces;
	}
	
	public static ArrayList<PlaceModel> UserSavedPlaces(int userID)
	{
		ArrayList <PlaceModel> savedPlaces = new ArrayList <>();
		try
    	
    	{
	    	Connection conn = DBConnection.getActiveConnection();
	    	String sql = "Select places.name,NoOfCheckins,rate from places, SavedPlaces where places.id = SavedPlaces.placeID and SavedPlaces.userID=?";
	    	PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, userID);
			ResultSet rs = stmt.executeQuery();
			while (rs.next())
			{	
				savedPlaces.add(new PlaceModel(rs.getInt("NoOfCheckins") ,rs.getString("name"), rs.getDouble("rate")));
				
			}
    	}
    	catch(SQLException e)
    	{
			e.printStackTrace();
    	}
		return savedPlaces;
	}
	
	
	
	@Override
	public int compareTo(PlaceModel o) 
	{
		if (numOfCheckIns <= o.numOfCheckIns) {
	          return -1;
	        }
	    return 1;
	}
	
	
}
