package com.models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class CheckIn 
{
	public String text;
	public String placeName;
	
	public CheckIn(String text, String placeName) {
		super();
		this.text = text;
		this.placeName = placeName;
	}
	
	public void setText(String text)
	{
		this.text = text;
	}
	public String getText()
	{
		return this.text;
	}
	public void setPlaceName(String name)
	{
		this.placeName = name;
	}
	public String getPlaceName()
	{
		return this.placeName;
	}

	public static ArrayList<CheckIn> ShowHomePage(int userID) {
		ArrayList <CheckIn> checkins = new ArrayList <>();
    	try
    	
    	{
	    	Connection conn = DBConnection.getActiveConnection();
	    	String sql = "Select CheckIns.text,places.name from places , CheckIns where places.id = CheckIns.PlaceID and CheckIns.userID in"
	    			+ "(Select FollowedUserID from Followers where FollowerID = ?)";
	    	PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, userID);
			ResultSet rs = stmt.executeQuery();
			while (rs.next())
			{	
				checkins.add(new CheckIn(rs.getString("text"),rs.getString("name")));
				
			}
			sql = "Select CheckIns.text,places.name from places , CheckIns where places.id = CheckIns.PlaceID and CheckIns.userID =?";
			
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, userID);
			rs = stmt.executeQuery();
			while (rs.next())
			{	
				checkins.add(new CheckIn(rs.getString("text"),rs.getString("name")));
				
			}
			
			sql = "SELECT CheckIns.text, places.name FROM places, CheckIns WHERE places.id = CheckIns.PlaceID AND CheckIns.CheckInID IN "
					+ "(SELECT Likes.CheckInID FROM Likes WHERE Likes.userID IN "
					+ "(SELECT FollowedUserID FROM Followers WHERE FollowerID =?))";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, userID);
			rs = stmt.executeQuery();
			while (rs.next())
			{	
				checkins.add(new CheckIn(rs.getString("text"),rs.getString("name")));
				
			}
			sql = "SELECT CheckIns.text, places.name FROM places, CheckIns WHERE places.id = CheckIns.PlaceID AND CheckIns.CheckInID IN "
			+ "(SELECT Comments.CheckInID FROM Comments WHERE Comments.userID IN "
			+ "(SELECT FollowedUserID FROM Followers WHERE FollowerID =?))";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, userID);
			rs = stmt.executeQuery();
			while (rs.next())
			{	
				checkins.add(new CheckIn(rs.getString("text"),rs.getString("name")));
				
			}
    	}
    	catch(SQLException e)
    	{
			e.printStackTrace();
    	}
    	return checkins;
	}
	
	
	public static ArrayList<CheckIn> UserCheckins(int userID)
	{
		ArrayList <CheckIn> Checkins = new ArrayList <>();
		try
    	
    	{
	    	Connection conn = DBConnection.getActiveConnection();
	    	String sql = "Select CheckIns.text,places.name from places , CheckIns where places.id = CheckIns.PlaceID and CheckIns.userID =?";
	    	PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, userID);
			ResultSet rs = stmt.executeQuery();
			while (rs.next())
			{	
				Checkins.add(new CheckIn(rs.getString("text"),rs.getString("name")));
				
			}
    	}
    	catch(SQLException e)
    	{
			e.printStackTrace();
    	}
		return Checkins;
	}
	

	
	public static Boolean likeCheckIn(int CheckinID, int userID) throws ParseException 
	{
		try{
			Connection conn = DBConnection.getActiveConnection();		
			String sql = "INSERT INTO Likes (CheckInID , userID) VALUES (?,?)";
			PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, CheckinID);
			stmt.setInt(2, userID);
			stmt.executeUpdate();
			
			stmt.clearBatch();
			int LikeID=0;
			sql="SELECT LikeID FROM Likes WHERE CheckInID=? AND userID=? ";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, CheckinID);
			stmt.setInt(2, userID);
			ResultSet rs = stmt.executeQuery();
	        while (rs.next()) 
	        {
	        	LikeID = rs.getInt("LikeID");
	        }
	        stmt.clearBatch();
			
			
			sql="INSERT INTO Actions(userID,actionID,type) VALUES(?,?,?)";
			stmt=conn.prepareStatement(sql);
			stmt.setInt(1, userID);
			stmt.setInt(2, LikeID);
			stmt.setString(3, "like");
			stmt.executeUpdate();
			
			stmt.clearBatch();
			
			int NotifiedUserID = 0;
			sql="SELECT userID FROM CheckIns WHERE CheckInID=?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, CheckinID);
			rs = stmt.executeQuery();
	        while (rs.next()) 
	        {
	        	NotifiedUserID = rs.getInt("userID");
	        }
	        stmt.clearBatch();
	        
			Date date = new Date();
	        SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
	        SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
			String timeAsString = timeFormatter.format(date);
			String DateAsString = dateFormatter.format(date);
	        Date d=dateFormatter.parse(DateAsString);
	        java.sql.Date SQLdate = new java.sql.Date(d.getTime());
	        d=timeFormatter.parse(timeAsString);
		    java.sql.Time SQLtime= new java.sql.Time(d.getTime());
            
			sql="INSERT INTO `Notification` (`userID`,`Date`,`Seen`,`Time`,`Text`,`CheckInID`,`Type`) VALUES (?,?,?,?,?,?,?) ";
			stmt=conn.prepareStatement(sql);
			stmt.setInt(1, NotifiedUserID);
			stmt.setDate(2,SQLdate);
			stmt.setBoolean(3, false);
			stmt.setTime(4, SQLtime);
			stmt.setString(5,UserModel.getUserName(userID) +" liked your checkin post.");
			stmt.setInt(6, CheckinID);
			stmt.setString(7, "like");
			stmt.executeUpdate();
			
			
			return true;
		}catch(SQLException e){
			e.printStackTrace();
		}
		return false;
	}
	
	public static Boolean Comment(int CheckinID,int userID,String Text) throws ParseException
	{

		try{
			Connection conn = DBConnection.getActiveConnection();		
			String sql = "INSERT INTO Comments(CheckInID,userID,Text) VALUES (?,?,?)";
			PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, CheckinID);
			stmt.setInt(2, userID);
			stmt.setString(3, Text);
			stmt.executeUpdate();
			stmt.clearBatch();
			
			int CommentID=0;
			sql="SELECT CommentID FROM Comments WHERE CheckInID=? AND userID=? AND Text=?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, CheckinID);
			stmt.setInt(2, userID);
			stmt.setString(3, Text);
			ResultSet rs = stmt.executeQuery();
	        while (rs.next()) 
	        {
	        	CommentID = rs.getInt("CommentID");
	        }
	        stmt.clearBatch();
			
			
			sql="INSERT INTO Actions(userID,actionID,type) VALUES(?,?,?)";
			stmt=conn.prepareStatement(sql);
			stmt.setInt(1, userID);
			stmt.setInt(2, CommentID);
			stmt.setString(3, "comment");
			stmt.executeUpdate();
			
			stmt.clearBatch();
			
			
			
			int NotifiedUserID = 0;
			sql="SELECT userID FROM CheckIns WHERE CheckInID=?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, CheckinID);
			rs = stmt.executeQuery();
	        while (rs.next()) 
	        {
	        	NotifiedUserID = rs.getInt("userID");
	        }
	        stmt.clearBatch();
	        
			Date date = new Date();
	        SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
	        SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
			String timeAsString = timeFormatter.format(date);
			String DateAsString = dateFormatter.format(date);
	        Date d=dateFormatter.parse(DateAsString);
	        java.sql.Date SQLdate = new java.sql.Date(d.getTime());
	        d=timeFormatter.parse(timeAsString);
		    java.sql.Time SQLtime= new java.sql.Time(d.getTime());
            
			sql="INSERT INTO `Notification` (`userID`,`Date`,`Seen`,`Time`,`Text`,`CheckInID`,`Type`) VALUES (?,?,?,?,?,?,?) ";
			stmt=conn.prepareStatement(sql);
			stmt.setInt(1, NotifiedUserID);
			stmt.setDate(2,SQLdate);
			stmt.setBoolean(3, false);
			stmt.setTime(4, SQLtime);
			stmt.setString(5,UserModel.getUserName(userID) +" commented on your checkin post.");
			stmt.setInt(6, CheckinID);
			stmt.setString(7, "comment");
			stmt.executeUpdate();
			
			return true;
		}catch(SQLException e){
			e.printStackTrace();
		}
		return false;
	}
	

	public static Boolean checkIn(int placeID, String text, int userID)
	{
		try{
			Connection conn = DBConnection.getActiveConnection();		
			String sql = "INSERT INTO CheckIns (placeID , Text , userID) VALUES (?,?,?)";
			PreparedStatement stmt;
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, placeID);
			stmt.setString(2, text);
			stmt.setInt(3, userID);
			stmt.executeUpdate();
			
			stmt.clearBatch();
			sql="Update places SET NoOfCheckins=NoOfCheckins+1 WHERE places.id=?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, placeID);
			stmt.executeUpdate();
			return true;
		}catch(SQLException e){
			e.printStackTrace();
		}
		return false;
	}
}

