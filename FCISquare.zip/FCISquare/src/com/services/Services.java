package com.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.server.mvc.Viewable;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.models.*;

@Path("/")
public class Services {


	@POST
	@Path("/signup")
	@Produces(MediaType.TEXT_PLAIN)
	public String signUp(@FormParam("name") String name,
			@FormParam("email") String email, @FormParam("pass") String pass) throws SQLException {
		JSONObject json = new JSONObject();
		if(UserModel.getUser(email))
		{
			json.put("Error", "User already exists");
			return json.toJSONString();

		}
		else 
		{
			UserModel user = UserModel.addNewUser(name, email, pass);
			json.put("id", user.getId());
			json.put("name", user.getName());
			json.put("email", user.getEmail());
			json.put("pass", user.getPass());
			json.put("lat", user.getLat());
			json.put("long", user.getLon());

		}
		return json.toJSONString();
	
	}
	@POST
	@Path("/login")
	@Produces(MediaType.TEXT_PLAIN)
	public String login(@FormParam("email") String email,@FormParam("pass") String pass)
	{
		JSONObject json = new JSONObject();
		if(UserModel.login(email, pass)==null)
		{
			json.put("Error","Wrong Email or Password");
		}
		else
		{
			UserModel user = UserModel.login(email, pass);
			json.put("userID", user.getId());
			json.put("name", user.getName());
			json.put("email", user.getEmail());
			json.put("pass", user.getPass());
			json.put("lat", user.getLat());
			json.put("longt", user.getLon());
		}
		return json.toJSONString();
	}
	
	@POST
	@Path("/updatePosition")
	@Produces(MediaType.TEXT_PLAIN)
	public String updatePosition(@FormParam("id") String id,@FormParam("lat") String lat, @FormParam("long") String lon)
	{
		Boolean status = UserModel.updateUserPosition(Integer.parseInt(id), Double.parseDouble(lat), Double.parseDouble(lon));
		JSONObject json = new JSONObject();
		json.put("status", status ? 1 : 0);
		return json.toJSONString();
	}
	
	@POST
	@Path("/followUser")
	@Produces(MediaType.TEXT_PLAIN)
	public String followUser(@FormParam("id") String id,@FormParam("email") String email) throws NumberFormatException, ParseException
	{
		Boolean status = UserModel.follow(Integer.parseInt(id), email);
		JSONObject json = new JSONObject();
		json.put("status", status ? 1 : 0);
		return json.toJSONString();
	}
	
	@POST
	@Path("/unfollowUser")
	@Produces(MediaType.TEXT_PLAIN)
	public String unFollow(@FormParam("id") String id, @FormParam("email") String email) throws SQLException{
		boolean status = UserModel.unfollowUser(Integer.parseInt(id),email);
		JSONObject json = new JSONObject();
		json.put("Status", status ? 1 : 0);
		return json.toJSONString();
	}

	@POST
	@Path("/getLastLocation")
	@Produces(MediaType.TEXT_PLAIN)
	public String getLastLocation(@FormParam("id") String id) {
		String lastLocation= UserModel.getLastLocation(Integer.parseInt(id));
		JSONObject json = new JSONObject();
		json.put("lastLocation" , lastLocation) ;
		return json.toJSONString();
	}
	
	@POST 
	@Path("/getAllFollowers")
	@Produces("application/json")
	public String getAllFollowers(@FormParam("id") String id)
	{
		List <UserModel> allFollowers = UserModel.getAllFollowers(Integer.parseInt(id));
		JSONArray json = new JSONArray() ;
		
		for (int i= 0 ; i<allFollowers.size(); i++){
			JSONObject object = new JSONObject () ;
			object.put("name", allFollowers.get(i).getName());
			object.put("email", allFollowers.get(i).getEmail());
			json.add(object); 
		}
		
		return json.toJSONString();
	}
	
	@POST 
	@Path("/getAllNotifications")
	@Produces("application/json")
	public String getAllNotifications(@FormParam("id") String id)
	{
		List <Notification> allNotifications = Notification.getAllNotifications(Integer.parseInt(id));
		JSONArray json = new JSONArray() ;
		for (int i= 0 ; i< allNotifications.size(); i++)
		{
			JSONObject object = new JSONObject () ;
			object.put("type", allNotifications.get(i).getType());
			object.put("text", allNotifications.get(i).getText());
			object.put("date", allNotifications.get(i).getDate());
			object.put("time", allNotifications.get(i).getTime());
			object.put("seen", allNotifications.get(i).isSeen());
			object.put("checkinID", allNotifications.get(i).getCheckinID());
			json.add(object); 
		}
		return json.toJSONString();
	}
	
	@POST 
	@Path("/getAllFollowNotif")
	@Produces("application/json")
	public String getAllFollowNotifications(@FormParam("id") String id)
	{
		List <Notification> allNotifications = Notification.getAllFollowNotifications(Integer.parseInt(id));
		JSONArray json = new JSONArray() ;
		for (int i= 0 ; i< allNotifications.size(); i++)
		{
			JSONObject object = new JSONObject () ;
			object.put("FollowerID", allNotifications.get(i).getFollowerID());
			object.put("text", allNotifications.get(i).getText());
			object.put("date", allNotifications.get(i).getDate());
			object.put("time", allNotifications.get(i).getTime());
			object.put("seen", allNotifications.get(i).isSeen());
			json.add(object); 
		}
		return json.toJSONString();
	}

	@POST 
	@Path("/respondToNotif")
	@Produces("application/json")
	public String respondToNotification(@FormParam("Notifid") String NotificationID)
	{
		int CheckinID=Notification.RespondToNotif(Integer.parseInt(NotificationID));		
		JSONObject json = new JSONObject();
		json.put("checkinID" , CheckinID) ;
		return json.toJSONString();
	}
	
	@POST
	@Path("/addNewPlaces")
	@Produces("application/json")
	public String addNewPlaces(@FormParam("name") String name, @FormParam("description") String description, @FormParam("lat") String lat, @FormParam("longt") String longt)
	{
		Boolean status = PlaceModel.addNewPlaces(name,description,Double.parseDouble(lat), Double.parseDouble(longt));
		JSONObject json = new JSONObject() ;
		json.put("status", status ? 1 : 0);
		return json.toJSONString();
	}
	
	@POST
	@Path("/checkIn")
	@Produces("application/json")
	public String checkIn(@FormParam("placeID") String placeID, @FormParam("Text") String text, @FormParam("userID") String userID)
	{
		Boolean status = CheckIn.checkIn(Integer.parseInt(placeID), text, Integer.parseInt(userID));
		JSONObject json = new JSONObject() ;
		json.put("status", status ? 1 : 0);
		return json.toJSONString();
	}
	
	@POST
	@Path("/comment")
	@Produces("application/json")
	public String Comment(@FormParam("CheckinID") String checkinID, @FormParam("userID") String userID, @FormParam("Text") String text) throws NumberFormatException, ParseException
	{
		Boolean status = CheckIn.Comment(Integer.parseInt(checkinID), Integer.parseInt(userID), text);
		JSONObject json = new JSONObject() ;
		json.put("status", status ? 1 : 0);
		return json.toJSONString();
	}
	
	@POST
	@Path("/savePlace")
	@Produces("application/json")
	public String savePlace(@FormParam("placeID") String placeID, @FormParam("userID") String userID)
	{
		Boolean status = PlaceModel.savePlace(Integer.parseInt(placeID), Integer.parseInt(userID));
		JSONObject json = new JSONObject() ;
		json.put("status", status ? 1 : 0);
		return json.toJSONString();
	}
	
	@POST
	@Path("/likeCheckIn")
	@Produces("application/json")
	public String likeCheckIn(@FormParam("checkInID") String checkInID, @FormParam("userID") String userID) throws NumberFormatException, ParseException
	{
		Boolean status = CheckIn.likeCheckIn(Integer.parseInt(checkInID), Integer.parseInt(userID));
		JSONObject json = new JSONObject() ;
		json.put("status", status ? 1 : 0);
		return json.toJSONString();
	}
	
	@POST 
	@Path("/showHomePage")
	@Produces("application/json")
	public String showHomePage(@FormParam("id") String id)
	{
		ArrayList <CheckIn> allFollowers = CheckIn.ShowHomePage(Integer.parseInt(id));
		JSONArray json = new JSONArray() ;
		
		for (int i= 0 ; i<allFollowers.size(); i++){
			JSONObject object = new JSONObject () ;
			object.put("text", allFollowers.get(i).getText());
			object.put("place", allFollowers.get(i).getPlaceName());
			json.add(object); 
		}
		
		ArrayList <PlaceModel> savedPlaces = PlaceModel.ShowSavedPlaces(Integer.parseInt(id));
		for (int i= 0 ; i<savedPlaces.size(); i++){
			JSONObject object = new JSONObject () ;
			object.put("name", savedPlaces.get(i).getName());
			object.put("rate", savedPlaces.get(i).getRate());
			object.put("noOfCheckins", savedPlaces.get(i).getNumOfCheckIns());
			json.add(object); 
		}
		
		return json.toJSONString();
	}
	
	@POST 
	@Path("/userCheckins")
	@Produces("application/json")
	public String userCheckins(@FormParam("id") String id)
	{
		List <CheckIn> checkins = CheckIn.UserCheckins(Integer.parseInt(id));
		JSONArray json = new JSONArray() ;
		
		for (int i= 0 ; i<checkins.size(); i++){
			JSONObject object = new JSONObject () ;
			object.put("place", checkins.get(i).getPlaceName());
			object.put("text", checkins.get(i).getText());
			json.add(object); 
		}
		
		return json.toJSONString();
	}
	
	@POST 
	@Path("/userSavedPlaces")
	@Produces("application/json")
	public String userSavedPlaces(@FormParam("id") String id)
	{
		List <PlaceModel> savedPlaces = PlaceModel.UserSavedPlaces(Integer.parseInt(id));
		JSONArray json = new JSONArray() ;
		
		for (int i= 0 ; i<savedPlaces.size(); i++){
			JSONObject object = new JSONObject () ;
			object.put("name", savedPlaces.get(i).getName());
			object.put("rate", savedPlaces.get(i).getRate());
			object.put("noOfCheckins", savedPlaces.get(i).getNumOfCheckIns());
			json.add(object); 
		}
		
		return json.toJSONString();
	}
	
	
	
	@POST 
	@Path("/sortNumOfCheckins")
	@Produces("application/json")
	public String sortCheckIns(@FormParam("id") String id)
	{
		ArrayList <PlaceModel> sortedPlaces = PlaceModel.SortPlaces(Integer.parseInt(id));
		JSONArray json = new JSONArray() ;
		
		for (int i= 0 ; i<sortedPlaces.size(); i++){
			JSONObject object = new JSONObject () ;
			object.put("Place", sortedPlaces.get(i).getName());
			object.put("NumberOfCheckins", sortedPlaces.get(i).getNumOfCheckIns());
			object.put("Rate", sortedPlaces.get(i).getRate());
			json.add(object); 
		}
		return json.toJSONString();
	}
	
	@POST 
	@Path("/sortRatedPlaces")
	@Produces("application/json")
	public String sortRatedPlaces(@FormParam("id") String id)
	{
		ArrayList <PlaceModel> sortedPlaces = PlaceModel.SortRatedPlaces(Integer.parseInt(id));
		JSONArray json = new JSONArray() ;
		
		for (int i= 0 ; i<sortedPlaces.size(); i++){
			JSONObject object = new JSONObject () ;
			object.put("Place", sortedPlaces.get(i).getName());
			object.put("NumberOfCheckins", sortedPlaces.get(i).getNumOfCheckIns());
			object.put("Rate", sortedPlaces.get(i).getRate());
			json.add(object); 
		}
		return json.toJSONString();
	}
	
	@POST 
	@Path("/ratePlace")
	@Produces("application/json")
	public String ratePlace(@FormParam("rate") String rate,@FormParam("placeId") String placeID)
	{
		boolean status = PlaceModel.ratePlace(Double.parseDouble(rate),Integer.parseInt(placeID));
		JSONObject json = new JSONObject();
		json.put("Status", status ? 1 : 0);
		return json.toJSONString();
	}
	
	@POST
	@Path("/undoAction")
	@Produces(MediaType.TEXT_PLAIN)
	public String undoAction(@FormParam("actionID") String actionID,@FormParam("userID") String userID,@FormParam("actionType") String actionType) throws SQLException
	{
		ActionModel action=new ActionModel(Integer.parseInt(actionID), Integer.parseInt(userID),actionType);
		boolean status = ActionModel.undoAction(action);
		JSONObject json = new JSONObject();
		json.put("Status", status ? 1 : 0);
		return json.toJSONString();
	}
	
	@POST 
	@Path("/getActions")
	@Produces("application/json")
	public String getActions(@FormParam("id") String id)
	{
		List <ActionModel> actions = ActionModel.HistoryOfActions(Integer.parseInt(id));
		JSONArray json = new JSONArray() ;
		for (int i= 0 ; i< actions.size(); i++)
		{
			JSONObject object = new JSONObject () ;
			object.put("actionID", actions.get(i).getActionID());
			object.put("type", actions.get(i).getActionType());
			json.add(object); 
		}
		return json.toJSONString();
	}
	
	
	@GET
	@Path("/")
	@Produces(MediaType.TEXT_PLAIN)
	public String getJson() {
		return "Hello after editing";
		// Connection URL:
		// mysql://$OPENSHIFT_MYSQL_DB_HOST:$OPENSHIFT_MYSQL_DB_PORT/
	}
}
